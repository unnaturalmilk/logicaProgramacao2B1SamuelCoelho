﻿namespace CapturandoDados
{
    internal class Form1
    {
    }
}