﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AppLista03
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txt1.Text);
            float num2 = float.Parse(txt2.Text);
            float num3 = float.Parse(txt3.Text);
            float soma;

            soma = num1 + num3;
            MessageBox.Show("Soma = " + soma);


        }

        private void btnMedia_Click(object sender, EventArgs e)
        {
            float num1 = float.Parse(txt1.Text);
            float num2 = float.Parse(txt2.Text);
            float num3 = float.Parse(txt3.Text);
            float media;

            media = (num1 + num2 + num3) / 3;

            MessageBox.Show("Media = " + media);
        }
    }
}
